export function Spinner() {
  return <div className="spinner"></div>;
}

export function SpinnerMini() {
  return <div className="spinner-mini"></div>;
}
