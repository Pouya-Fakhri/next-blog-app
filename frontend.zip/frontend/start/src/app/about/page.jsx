export const metadata = {
  //   title: "About",
  title: {
    absolute: "About", // ignore %s in parent layout.
  },
};

function About() {
  return <div>About</div>;
}
export default About;
