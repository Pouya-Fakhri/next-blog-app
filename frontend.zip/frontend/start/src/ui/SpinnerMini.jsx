function SpinnerMini() {
  return <div className="spinner-mini"></div>;
}
export default SpinnerMini;
